
# 一些相关资料

## 关于方差分析中的多重比较（Multiple Comparison Tests）


- [PMCMR](https://cran.r-project.org/web/packages/PMCMR/vignettes/PMCMR.pdf) 包
- [R companion](http://rcompanion.org/handbook/) 书
- [Multicomparsion Procedure List](https://analyse-it.com/docs/user-guide/comparegroups/multiplecomparisonprocedures)






